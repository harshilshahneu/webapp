#!/bin/bash

# initial commands
sudo apt update
sudo apt upgrade

# install unzip
sudo apt install unzip

#install mariadb
sudo apt install mariadb-server

#unzip the project
unzip webapp.zip

cd webapp/ || exit

# create .env
cat<<EOL > .env
PORT=8080
DB_HOST=127.0.0.1
DB_NAME=HealthConnectDB
DB_USER=admin
DB_PASSWORD=password
DB_DIALECT=mysql
NODE_ENV=prod
USER_CSV_PATH=/opt/users.csv
EOL

#check env
cat .env

#configure mariadb username
echo "GRANT ALL ON *.* TO 'admin'@'localhost' IDENTIFIED BY 'password' WITH GRANT OPTION;" | sudo mariadb

echo "FLUSH PRIVILEGES;" | sudo mariadb

#create database
echo "CREATE DATABASE HealthConnectDB;" | sudo mariadb

#install the npm dependencies
npm install
